# Final project writeup

Explain your strategy here. Limit yourself to two pages, either markdown or pdf.
